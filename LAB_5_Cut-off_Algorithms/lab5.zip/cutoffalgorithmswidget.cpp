#include "cutoffalgorithmswidget.h"

CutOffAlgorithmsWidget::CutOffAlgorithmsWidget(QWidget *parent): QWidget{parent}
{
    mainWgt = new QCustomPlot();
    QHBoxLayout *mainLayout = new QHBoxLayout(this);
    mainLayout->addWidget(mainWgt);
    mainWgt->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    mainWgt->setInteraction(QCP::iRangeDrag,true);
    mainWgt->setInteraction(QCP::iRangeZoom,true);
    GoToOrigin();

    visiblePartPen.setWidth(3);
    visiblePartPen.setColor(Qt::blue);
    cuttingPartPen.setWidth(3);
    cuttingPartPen.setColor(Qt::red);
    cuttingPartPen.setStyle(Qt::DotLine);
    windowPen.setWidth(5);
    windowPen.setColor(Qt::black);

    digitValidator.setPattern("^-?[0-9]*$");
    currentGraph = -1;
    mainWgt->legend->setVisible(true);
    mainWgt->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignBottom | Qt::AlignRight);
}

CutOffAlgorithmsWidget::~CutOffAlgorithmsWidget(){}

bool CutOffAlgorithmsWidget::process(QFile file, Type type)
{
    if (!file.open(QIODevice::ReadOnly))
        return false;
    else if (file.atEnd())
        return false;
    Clear();

    n = file.readLine().toInt();
    if (type == SECTION_TYPE)
        m = 4;
    else
    {
        if (file.atEnd())
            return false;
        else
            m = file.readLine().toInt();
    }

    QString data;
    QStringList points;
    int x1, y1, x2, y2;
    setLegend();
    while (!file.atEnd())
    {
        data = file.readLine();
        data = data.trimmed();
        points = data.split(" ");
        if (points.size() != 4 || !digitValidator.match(points[0]).hasMatch() ||
                !digitValidator.match(points[1]).hasMatch() ||
                !digitValidator.match(points[2]).hasMatch() ||
                !digitValidator.match(points[3]).hasMatch() ||
                (points[0] == points[2] && points[1] == points[3]))
        {
            Clear();
            return false;
        }

        x1 = points[0].toInt();
        y1 = points[1].toInt();
        x2 = points[2].toInt();
        y2 = points[3].toInt();
        if (type == SECTION_TYPE)
            drawSectionBySutherland_Cohen(x1, y1, x2, y2);
        else
        {

        }
        n--;
    }

    if (n != -1)
    {
        Clear();
        return false;
    }
    mainWgt->replot();
    return true;
}

void CutOffAlgorithmsWidget::drawSectionBySutherland_Cohen(int x1, int y1, int x2, int y2)
{
    mainWgt->addGraph();
    currentGraph++;
    mainWgt->graph(currentGraph)->setName("First graph");
    mainWgt->graph(currentGraph)->addData(x1, y1);
    mainWgt->graph(currentGraph)->addData(x2, y2);
    mainWgt->setAutoAddPlottableToLegend(false);
}

void CutOffAlgorithmsWidget::setLegend()
{
        mainWgt->addGraph();
        mainWgt->graph(0)->setPen(visiblePartPen);
        mainWgt->graph(0)->setName("Visible");
        mainWgt->addGraph();
        mainWgt->graph(1)->setPen(cuttingPartPen);
        mainWgt->graph(1)->setName("Cutting");
        mainWgt->addGraph();
        mainWgt->graph(2)->setName("Window");
        mainWgt->graph(2)->setPen(windowPen);
        mainWgt->setAutoAddPlottableToLegend(false);
        currentGraph = 2;
}

bool CutOffAlgorithmsWidget::checkData()
{

}

void CutOffAlgorithmsWidget::Clear()
{
    mainWgt->clearGraphs();
    currentGraph = -1;
    mainWgt->setAutoAddPlottableToLegend(true);
    figures.clear();
    mainWgt->replot();
}

void CutOffAlgorithmsWidget::GoToOrigin()
{
    mainWgt->xAxis->setRange(-500, 500);
    mainWgt->yAxis->setRange(-500, 500);
    mainWgt->replot();
}
