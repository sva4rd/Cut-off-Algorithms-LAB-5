#ifndef CUTOFFALGORITHMSWIDGET_H
#define CUTOFFALGORITHMSWIDGET_H

#include <QtWidgets>
#include "qcustomplot.h"

class CutOffAlgorithmsWidget : public QWidget
{
    Q_OBJECT
public:
    CutOffAlgorithmsWidget(QWidget *parent = nullptr);
    ~CutOffAlgorithmsWidget();

    enum Type
    {
        SECTION_TYPE,
        POLYGON_TYPE
    };

    bool process(QFile file, Type type);
    void Clear();
    void GoToOrigin();

private:
    QCustomPlot *mainWgt;
    QRegularExpression digitValidator;
    QPen visiblePartPen;
    QPen cuttingPartPen;
    QPen windowPen;

    QVector <QStringList> figures;
    int n;
    int m;
    int currentGraph;

    void drawSectionBySutherland_Cohen(int x1, int y1, int x2, int y2);
    void setLegend();
};

#endif // CUTOFFALGORITHMSWIDGET_H
